package com.layfones.hellosftp.sftp.core;

public final class Util {

    public static boolean isEmptyText(String text) {
        return null == text || "".equals(text);
    }

}
